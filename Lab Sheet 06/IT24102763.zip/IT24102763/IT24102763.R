setwd("E:\\Y2S1\\PS\\Labs\\Lab 06")

##Exercise

#Part 1 
# 1)Binomial Distribution
#    x~Bin(n = 50, p = 0.85 )

# 2)P(X >= 47)
pbinom(47,50,0.85,lower.tail = FALSE)

#Part 2
# 1) X - Number of customer calls recevied per hour

# 2)Poisson Distribution
#     x~Poisson(λ = 12)

# 3)P(X=15)
dpois(15,12)
  