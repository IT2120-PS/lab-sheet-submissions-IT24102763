# Set the working directory 
setwd("E:\\Y2S1\\PS\\Labs\\Ps Lab 05\\IT24102763")  

# Import the dataset into R
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Change the column name to x1
colnames(Delivery_Times) <- c("x1")

# Attach the data for easier access to the column
attach(Delivery_Times)

# Create the histogram
histogram <- hist(x1, 
                  breaks = seq(20, 70, length = 10),  # Create 9 bins (10 breaks)
                  right = TRUE,                       # Right-open intervals
                  main = "Histogram of Delivery Times", 
                  xlab = "Delivery Time (minutes)", 
                  col = "lightblue", 
                  border = "black")

# Extract frequency counts, midpoints, and class intervals for the cumulative frequency plot
freq <- histogram$counts
mids <- histogram$mids
breaks <- round(histogram$breaks)

# Create the cumulative frequency (ogive)
cum.freq <- cumsum(freq)

# Plot the cumulative frequency polygon (ogive)
plot(breaks, c(0, cum.freq), type = 'o', 
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times", 
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency", 
     col = "blue", pch = 16, ylim = c(0, max(cum.freq)))

# Display the cumulative frequency table
cbind(Upper = breaks, CumFreq = c(0, cum.freq))

